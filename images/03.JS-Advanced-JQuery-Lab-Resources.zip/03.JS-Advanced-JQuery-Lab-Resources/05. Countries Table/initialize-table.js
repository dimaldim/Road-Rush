function initializeTable() {
	console.log('TODO...');
}