function extractText() {
   // TODO:
}
