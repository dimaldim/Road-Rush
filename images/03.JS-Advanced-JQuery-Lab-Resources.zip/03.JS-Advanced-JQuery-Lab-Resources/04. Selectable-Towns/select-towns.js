function attachEvents() {
	// TODO:
}